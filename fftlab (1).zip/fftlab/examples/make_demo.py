"""Gera demo_rolamento.csv: 2 canais (acelerometro com falha de pista externa + referencia)."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "tests"))
import numpy as np
from test_fftlab import bearing_signal, FS

t, x, fdef = bearing_signal(10)
rng = np.random.default_rng(5)
ref = 0.7 * x + 0.15 * rng.normal(size=x.size)
out = pathlib.Path(__file__).with_name("demo_rolamento.csv")
with out.open("w") as f:
    f.write("tempo_s;acelerometro;referencia\n")
    for ti, a, b in zip(t, x, ref):
        f.write(f"{ti:.6f};{a:.5f};{b:.5f}\n")
print(out, f"BPFO esperado = {fdef:.2f} Hz (rotacao 1500 rpm, rolamento 6205)")
