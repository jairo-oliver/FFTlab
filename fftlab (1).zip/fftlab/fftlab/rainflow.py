"""Rainflow cycle counting (ASTM E1049-85, 3-point stack algorithm) + Miner damage."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


def reversals(x) -> np.ndarray:
    """Reduce a series to its turning points (peaks and valleys), keeping first and last."""
    x = np.asarray(x, dtype=float)
    if x.size < 2:
        return x.copy()
    # drop consecutive duplicates
    keep = np.concatenate(([True], np.diff(x) != 0))
    x = x[keep]
    if x.size < 3:
        return x
    d = np.diff(x)
    turn = np.concatenate(([True], d[:-1] * d[1:] < 0, [True]))
    return x[turn]


@dataclass
class Cycles:
    ranges: np.ndarray   # peak-to-valley range of each counted (half-)cycle
    means: np.ndarray
    counts: np.ndarray   # 1.0 = full cycle, 0.5 = half cycle

    @property
    def total(self) -> float:
        return float(self.counts.sum())


def count_cycles(x) -> Cycles:
    pts = reversals(x)
    if pts.size < 3:
        raise ValueError("Rainflow: menos de 3 pontos de reversao encontrados")
    stack: list[float] = []
    r, m, c = [], [], []
    for p in pts:
        stack.append(float(p))
        while len(stack) >= 3:
            X = abs(stack[-1] - stack[-2])
            Y = abs(stack[-2] - stack[-3])
            if X < Y:
                break
            mean = 0.5 * (stack[-2] + stack[-3])
            if len(stack) == 3:
                r.append(Y); m.append(mean); c.append(0.5)
                stack.pop(0)
            else:
                r.append(Y); m.append(mean); c.append(1.0)
                last = stack.pop()
                del stack[-2:]
                stack.append(last)
    for a, b in zip(stack[:-1], stack[1:]):
        r.append(abs(a - b)); m.append(0.5 * (a + b)); c.append(0.5)
    return Cycles(np.array(r), np.array(m), np.array(c))


def range_histogram(cyc: Cycles, bins=20):
    """Cycles per range bin. Returns (bin_centres, counts, edges)."""
    counts, edges = np.histogram(cyc.ranges, bins=bins, weights=cyc.counts)
    return 0.5 * (edges[1:] + edges[:-1]), counts, edges


def range_mean_matrix(cyc: Cycles, bins=(16, 16)):
    h, re, me = np.histogram2d(cyc.ranges, cyc.means, bins=bins, weights=cyc.counts)
    return h, re, me


def miner_damage(cyc: Cycles, m: float, ref_amplitude: float, ref_cycles: float,
                 use_amplitude=True) -> float:
    """Palmgren-Miner damage with a Basquin S-N curve N = ref_cycles * (S_ref/S)^m.

    S is the stress amplitude (range/2) when use_amplitude=True, else the range.
    No mean-stress correction is applied.
    """
    s = cyc.ranges / 2.0 if use_amplitude else cyc.ranges
    s = np.maximum(s, 1e-30)
    n_fail = ref_cycles * (ref_amplitude / s) ** m
    return float(np.sum(cyc.counts / n_fail))


def damage_equivalent_range(cyc: Cycles, m: float, n_eq: float | None = None) -> float:
    """Constant-amplitude range producing the same damage in n_eq cycles (default: total)."""
    n_eq = n_eq or cyc.total
    return float((np.sum(cyc.counts * cyc.ranges ** m) / n_eq) ** (1.0 / m))
