"""FFTLab - free vibration / signal analysis toolkit (MIT)."""
__version__ = "0.3.0"
