"""Rolling-bearing defect frequencies and a simple .BRG table format.

.BRG text format (UTF-8, one bearing per line, ';' separated, '#' comments):

    # name ; n_balls ; ball_diameter ; pitch_diameter ; contact_angle_deg
    6205 ; 9 ; 7.94 ; 39.04 ; 0
    SKF 22222 ; 20 ; 24.0 ; 150.0 ; 10.5

Any consistent length unit may be used (only the ratio Bd/Pd matters).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Bearing:
    name: str
    n_balls: int
    ball_d: float
    pitch_d: float
    contact_deg: float = 0.0

    def __post_init__(self):
        if self.n_balls < 1 or self.ball_d <= 0 or self.pitch_d <= self.ball_d:
            raise ValueError(f"Geometria invalida para rolamento {self.name!r}")

    @property
    def _r(self) -> float:
        return self.ball_d / self.pitch_d * math.cos(math.radians(self.contact_deg))

    # Orders: multiples of the SHAFT rotation frequency (inner race rotating, outer fixed)
    @property
    def ftf_order(self) -> float:
        return 0.5 * (1.0 - self._r)

    @property
    def bpfo_order(self) -> float:
        return 0.5 * self.n_balls * (1.0 - self._r)

    @property
    def bpfi_order(self) -> float:
        return 0.5 * self.n_balls * (1.0 + self._r)

    @property
    def bsf_order(self) -> float:
        bd_pd = self.ball_d / self.pitch_d
        return 0.5 * (self.pitch_d / self.ball_d) * (1.0 - self._r ** 2) if bd_pd else 0.0

    def frequencies(self, shaft_hz: float) -> dict:
        """Defect frequencies in Hz for a given shaft speed (Hz)."""
        return {
            "FTF": self.ftf_order * shaft_hz,
            "BPFO": self.bpfo_order * shaft_hz,
            "BPFI": self.bpfi_order * shaft_hz,
            "BSF": self.bsf_order * shaft_hz,
            "2xBSF": 2 * self.bsf_order * shaft_hz,
        }


def rpm_to_hz(rpm: float) -> float:
    return rpm / 60.0


def load_brg(path) -> list[Bearing]:
    out = []
    for ln, raw in enumerate(Path(path).read_text(encoding="utf-8-sig").splitlines(), 1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        parts = [p.strip() for p in line.split(";")]
        if len(parts) < 4:
            raise ValueError(f"{path}:{ln}: esperado 'nome;n_esferas;Bd;Pd[;angulo]'")
        try:
            out.append(Bearing(parts[0], int(parts[1]), float(parts[2].replace(",", ".")),
                               float(parts[3].replace(",", ".")),
                               float(parts[4].replace(",", ".")) if len(parts) > 4 and parts[4] else 0.0))
        except ValueError as exc:
            raise ValueError(f"{path}:{ln}: {exc}") from exc
    if not out:
        raise ValueError(f"{path}: nenhum rolamento encontrado")
    return out


def save_brg(path, bearings) -> None:
    lines = ["# name ; n_balls ; ball_diameter ; pitch_diameter ; contact_angle_deg"]
    for b in bearings:
        lines.append(f"{b.name} ; {b.n_balls} ; {b.ball_d:g} ; {b.pitch_d:g} ; {b.contact_deg:g}")
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")
