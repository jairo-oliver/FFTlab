"""Matplotlib figure builders. Pure functions: take a Figure, draw on it, return it."""
from __future__ import annotations

import numpy as np
from matplotlib.figure import Figure

from . import dsp, rainflow as rf


def _style(ax, xlabel, ylabel, title=None):
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title)
    ax.grid(True, alpha=0.3)


def draw_marks(ax, marks, ymax=None, color="tab:red"):
    """marks: list of (freq, label). Draws dashed vertical lines with labels."""
    for fm, lab in marks:
        ax.axvline(fm, color=color, ls="--", lw=0.8, alpha=0.8)
        ax.annotate(lab, (fm, 1.0), xycoords=("data", "axes fraction"), rotation=90,
                    va="top", ha="right", fontsize=7, color=color)


def plot_time(fig: Figure, t, series: dict, unit=""):
    fig.clear()
    ax = fig.add_subplot(111)
    for name, y in series.items():
        ax.plot(t[: len(y)], y, lw=0.7, label=name)
    ax.legend(loc="upper right", fontsize=8)
    _style(ax, "Tempo [s]", f"Amplitude [{unit}]" if unit else "Amplitude")
    fig.tight_layout()
    return fig


def plot_spectrum(fig, spectra: dict, scaling="peak", db=False, logx=False, xlim=None, marks=None, unit=""):
    """spectra: name -> (f, A)."""
    fig.clear()
    ax = fig.add_subplot(111)
    for name, (f, a) in spectra.items():
        ax.plot(f, dsp.to_db(a) if db else a, lw=0.8, label=name)
    ylab = {"peak": "Amplitude (pico)", "rms": "Amplitude (RMS)", "psd": "PSD [unid²/Hz]"}[scaling]
    if db:
        ylab += " [dB]"
    elif unit and scaling != "psd":
        ylab += f" [{unit}]"
    if logx:
        ax.set_xscale("log")
    if xlim:
        ax.set_xlim(*xlim)
    if marks:
        draw_marks(ax, marks)
    if len(spectra) > 1:
        ax.legend(fontsize=8)
    _style(ax, "Frequencia [Hz]", ylab, "Auto-espectro")
    fig.tight_layout()
    return fig


def plot_coherence(fig, f, c, xlim=None, marks=None):
    fig.clear()
    ax = fig.add_subplot(111)
    ax.plot(f, c, lw=0.8)
    ax.set_ylim(0, 1.05)
    if xlim:
        ax.set_xlim(*xlim)
    if marks:
        draw_marks(ax, marks)
    _style(ax, "Frequencia [Hz]", "Coerencia γ²", "Coerencia")
    fig.tight_layout()
    return fig


def plot_envelope(fig, f, a, t, x, env, band, method, xlim=None, marks=None):
    fig.clear()
    ax1 = fig.add_subplot(211)
    n = min(len(t), 20000)
    ax1.plot(t[:n], x[:n], lw=0.4, color="0.6", label="sinal")
    ax1.plot(t[:n], env[:n] if method == 1 else np.sqrt(env[:n]), lw=0.8, color="tab:red", label="envelope")
    ax1.legend(fontsize=8, loc="upper right")
    _style(ax1, "Tempo [s]", "Amplitude", f"Envelope {method} - banda {band[0]:g}-{band[1]:g} Hz")
    ax2 = fig.add_subplot(212)
    ax2.plot(f, a, lw=0.8)
    if xlim:
        ax2.set_xlim(*xlim)
    if marks:
        draw_marks(ax2, marks)
    _style(ax2, "Frequencia [Hz]", "Espectro do envelope")
    fig.tight_layout()
    return fig


def plot_waterfall(fig, f, t, s, mode="lines", fmax=None, db=False, max_lines=40):
    fig.clear()
    ax = fig.add_subplot(111)
    if fmax:
        k = f <= fmax
        f, s = f[k], s[k]
    z = dsp.to_db(s) if db else s
    if mode == "top":
        im = ax.pcolormesh(f, t, z.T, shading="auto", cmap="viridis")
        fig.colorbar(im, ax=ax, label="dB" if db else "Amplitude")
        _style(ax, "Frequencia [Hz]", "Tempo [s]", "Waterfall (vista superior)")
    else:
        step = max(1, z.shape[1] // max_lines)
        idx = list(range(0, z.shape[1], step))
        span = float(np.nanmax(z) - np.nanmin(z)) or 1.0
        off = span * 0.04
        n = len(idx)
        for k, j in enumerate(idx):          # k=0: inicio do registro, na frente
            base = k * off
            zo = (n - k) * 2                 # frente desenhada por cima
            ax.fill_between(f, base, z[:, j] + base, color="white", zorder=zo)
            ax.plot(f, z[:, j] + base, lw=0.6, color="k", zorder=zo + 1)
        ax.set_yticks([])
        _style(ax, "Frequencia [Hz]", f"tempo: {t[0]:.1f} s (frente) -> {t[idx[-1]]:.1f} s (fundo)", "Waterfall")
    fig.tight_layout()
    return fig


def plot_rainflow(fig, cyc: rf.Cycles, series=None, t=None, bins=20, unit=""):
    fig.clear()
    ax1 = fig.add_subplot(221)
    if series is not None:
        ax1.plot(t if t is not None else np.arange(len(series)), series, lw=0.5)
    _style(ax1, "Tempo [s]" if t is not None else "Amostra", unit or "Valor", "Historico")
    ax2 = fig.add_subplot(222)
    c, n, e = rf.range_histogram(cyc, bins)
    ax2.bar(c, n, width=(e[1] - e[0]) * 0.9)
    _style(ax2, f"Faixa [{unit}]" if unit else "Faixa", "Ciclos", f"Histograma de faixas (total {cyc.total:.1f})")
    ax3 = fig.add_subplot(223)
    h, re, me = rf.range_mean_matrix(cyc, (bins, bins))
    im = ax3.pcolormesh(me, re, h, shading="auto", cmap="magma")
    fig.colorbar(im, ax=ax3, label="ciclos")
    _style(ax3, "Media", "Faixa", "Matriz faixa x media")
    ax4 = fig.add_subplot(224)
    order = np.argsort(cyc.ranges)[::-1]
    cum = np.cumsum(cyc.counts[order])
    ax4.semilogx(cum, cyc.ranges[order], drawstyle="steps-post")
    _style(ax4, "Ciclos acumulados (>= faixa)", "Faixa", "Colecao de cargas")
    fig.tight_layout()
    return fig
