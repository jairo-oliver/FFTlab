"""Tkinter + matplotlib front-end."""
from __future__ import annotations

import csv
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure

from . import __version__, bearings, dsp, readers
from .session import Session

TABS = ["Tempo", "Espectro", "Coerência", "Envelope", "Waterfall", "Rainflow"]
CURSOR_TABS = {"Espectro", "Coerência", "Envelope"}


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"FFTLab {__version__} - análise de vibração")
        self.geometry("1400x850")
        self.s = Session()
        self.table: list[bearings.Bearing] = []
        self._build_vars()
        self._build_ui()
        self._build_menu()

    # ------------------------------------------------------------------ vars
    def _build_vars(self):
        V = tk
        self.v = {
            "window": V.StringVar(value="hann"), "nperseg": V.StringVar(value="16384"),
            "overlap": V.StringVar(value="50"), "scaling": V.StringVar(value="peak"),
            "db": V.BooleanVar(value=False), "logx": V.BooleanVar(value=False),
            "fmin": V.StringVar(value="0"), "fmax": V.StringVar(value="0"),
            "fs": V.StringVar(value=""),
            "rpm": V.StringVar(value="0"), "n_harm": V.StringVar(value="5"),
            "show_bearing": V.BooleanVar(value=True), "bearing": V.StringVar(),
            "cursor_harm": V.BooleanVar(value=True),
            "band_lo": V.StringVar(value="2000"), "band_hi": V.StringVar(value="5000"),
            "env_method": V.StringVar(value="1"), "env_fmax": V.StringVar(value="500"),
            "wf_nperseg": V.StringVar(value="2048"), "wf_mode": V.StringVar(value="lines"),
            "rf_bins": V.StringVar(value="20"), "sn_m": V.StringVar(value="3"),
            "sn_ref_amp": V.StringVar(value="100"), "sn_ref_cycles": V.StringVar(value="1e6"),
            "ref_channel": V.StringVar(),
        }
        self.status = tk.StringVar(value="Abra um arquivo (.LTD, .CSV, .WAV, .NPY).")
        self.info = tk.StringVar(value="")

    def _read_params(self):
        g = lambda k: self.v[k].get()
        p = self.s.params
        p.window, p.scaling = g("window"), g("scaling")
        p.nperseg, p.overlap = int(float(g("nperseg"))), float(g("overlap")) / 100.0
        p.db, p.logx = g("db"), g("logx")
        p.fmin, p.fmax = float(g("fmin") or 0), float(g("fmax") or 0)
        p.rpm, p.n_harm = float(g("rpm") or 0), int(float(g("n_harm") or 5))
        p.show_bearing = g("show_bearing")
        p.band_lo, p.band_hi = float(g("band_lo")), float(g("band_hi"))
        p.env_method, p.env_fmax = int(g("env_method")), float(g("env_fmax") or 0)
        p.wf_nperseg, p.wf_mode = int(float(g("wf_nperseg"))), g("wf_mode")
        p.rf_bins, p.sn_m = int(float(g("rf_bins"))), float(g("sn_m"))
        p.sn_ref_amp, p.sn_ref_cycles = float(g("sn_ref_amp")), float(g("sn_ref_cycles"))
        self.s.cursor_harmonics = g("cursor_harm")
        name = g("bearing")
        self.s.bearing = next((b for b in self.table if b.name == name), None)

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        paned = ttk.PanedWindow(self, orient="horizontal")
        paned.pack(fill="both", expand=True)
        left = ttk.Frame(paned, padding=6)
        right = ttk.Frame(paned)
        paned.add(left, weight=0)
        paned.add(right, weight=1)

        def row(parent, label, key, width=9, values=None):
            f = ttk.Frame(parent)
            f.pack(fill="x", pady=1)
            ttk.Label(f, text=label, width=17).pack(side="left")
            if values:
                w = ttk.Combobox(f, textvariable=self.v[key], values=values, width=width - 1, state="readonly")
            else:
                w = ttk.Entry(f, textvariable=self.v[key], width=width)
            w.pack(side="left")
            return w

        ttk.Button(left, text="Abrir arquivo…", command=self.open_file).pack(fill="x")
        ttk.Button(left, text="Importar binário bruto…", command=self.open_raw).pack(fill="x", pady=2)
        row(left, "fs [Hz] (vazio=auto)", "fs")
        ttk.Label(left, text="Canais (Ctrl/Shift p/ vários):").pack(anchor="w", pady=(6, 0))
        self.lb = tk.Listbox(left, selectmode="extended", height=6, exportselection=False)
        self.lb.pack(fill="x")
        self.cb_ref = row(left, "Canal ref. (coer.)", "ref_channel", 12, values=[])

        lf = ttk.LabelFrame(left, text="FFT / Espectro", padding=4)
        lf.pack(fill="x", pady=4)
        row(lf, "Janela", "window", 10, list(dsp.WINDOWS))
        row(lf, "Pontos/bloco", "nperseg", 10, ["1024", "2048", "4096", "8192", "16384", "32768", "65536"]).configure(state="normal")
        row(lf, "Sobreposição [%]", "overlap")
        row(lf, "Escala", "scaling", 10, ["peak", "rms", "psd"])
        row(lf, "f min [Hz]", "fmin")
        row(lf, "f max [Hz] (0=auto)", "fmax")
        ttk.Checkbutton(lf, text="dB", variable=self.v["db"]).pack(side="left")
        ttk.Checkbutton(lf, text="Eixo f log", variable=self.v["logx"]).pack(side="left")

        lm = ttk.LabelFrame(left, text="Máquina / Rolamento / Cursores", padding=4)
        lm.pack(fill="x", pady=4)
        row(lm, "Rotação [rpm]", "rpm")
        row(lm, "Nº harmônicos", "n_harm")
        ttk.Button(lm, text="Estimar rpm (pico 1x do canal)", command=self.estimate_rpm).pack(fill="x")
        ttk.Button(lm, text="Carregar tabela .BRG…", command=self.load_brg).pack(fill="x")
        self.cb_brg = row(lm, "Rolamento", "bearing", 14, [])
        self.cb_brg.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        ttk.Checkbutton(lm, text="Marcar BPFO/BPFI/BSF/FTF", variable=self.v["show_bearing"]).pack(anchor="w")
        ttk.Checkbutton(lm, text="Cursor com harmônicos (clique no gráfico)", variable=self.v["cursor_harm"]).pack(anchor="w")
        ttk.Button(lm, text="Limpar cursor", command=self.clear_cursor).pack(fill="x")

        le = ttk.LabelFrame(left, text="Envelope", padding=4)
        le.pack(fill="x", pady=4)
        row(le, "Banda inf [Hz]", "band_lo")
        row(le, "Banda sup [Hz]", "band_hi")
        row(le, "Método (1 ou 2)", "env_method", 10, ["1", "2"])
        row(le, "f max env. [Hz]", "env_fmax")

        lw = ttk.LabelFrame(left, text="Waterfall", padding=4)
        lw.pack(fill="x", pady=4)
        row(lw, "Pontos/bloco", "wf_nperseg")
        row(lw, "Vista", "wf_mode", 10, ["lines", "top"])

        lr = ttk.LabelFrame(left, text="Rainflow / Fadiga (Miner)", padding=4)
        lr.pack(fill="x", pady=4)
        row(lr, "Classes", "rf_bins")
        row(lr, "Expoente m (S-N)", "sn_m")
        row(lr, "Amplitude ref.", "sn_ref_amp")
        row(lr, "Ciclos ref.", "sn_ref_cycles")

        ttk.Button(left, text="Atualizar (F5)", command=self.refresh).pack(fill="x", pady=6)

        self.nb = ttk.Notebook(right)
        self.nb.pack(fill="both", expand=True)
        self.figs, self.canvases = {}, {}
        for name in TABS:
            fr = ttk.Frame(self.nb)
            self.nb.add(fr, text=name)
            fig = Figure(figsize=(8, 5), dpi=100)
            cv = FigureCanvasTkAgg(fig, master=fr)
            NavigationToolbar2Tk(cv, fr).update()
            cv.get_tk_widget().pack(fill="both", expand=True)
            cv.mpl_connect("button_press_event", lambda ev, n=name: self.on_click(ev, n))
            cv.mpl_connect("motion_notify_event", self.on_motion)
            self.figs[name], self.canvases[name] = fig, cv
        self.nb.bind("<<NotebookTabChanged>>", lambda e: self.refresh())
        ttk.Label(right, textvariable=self.info, wraplength=1000, foreground="#0a4").pack(fill="x", padx=6)
        ttk.Label(right, textvariable=self.status, relief="sunken", anchor="w").pack(fill="x")
        self.bind("<F5>", lambda e: self.refresh())

    def _build_menu(self):
        m = tk.Menu(self)
        fm = tk.Menu(m, tearoff=0)
        fm.add_command(label="Abrir…", command=self.open_file)
        fm.add_command(label="Importar binário bruto…", command=self.open_raw)
        fm.add_separator()
        fm.add_command(label="Salvar gráfico atual (PNG)…", command=self.save_fig)
        fm.add_command(label="Exportar espectro atual (CSV)…", command=self.export_csv)
        fm.add_separator()
        fm.add_command(label="Sair", command=self.destroy)
        m.add_cascade(label="Arquivo", menu=fm)
        hm = tk.Menu(m, tearoff=0)
        hm.add_command(label="Sobre", command=lambda: messagebox.showinfo(
            "FFTLab", f"FFTLab {__version__}\nLicença MIT - software livre.\n"
                      "Espectro, coerência, envelope, waterfall, rolamentos e rainflow."))
        m.add_cascade(label="Ajuda", menu=hm)
        self.config(menu=m)

    # ------------------------------------------------------------------ data
    def _set_dataset(self, ds: readers.Dataset):
        self.s.load(ds)
        self.lb.delete(0, "end")
        for n in ds.names:
            self.lb.insert("end", n)
        self.lb.selection_set(0)
        self.cb_ref.configure(values=ds.names)
        self.v["ref_channel"].set(ds.names[-1])
        p = self.s.params
        self.v["band_lo"].set(f"{p.band_lo:g}")
        self.v["band_hi"].set(f"{p.band_hi:g}")
        self.v["env_fmax"].set(f"{p.env_fmax:g}")
        self.v["nperseg"].set(str(p.nperseg))
        self.status.set(f"{Path(ds.source).name}: fs={ds.fs:g} Hz, {ds.n_samples} amostras, "
                        f"{len(ds.names)} canais. {ds.notes}")
        self.refresh()

    def open_file(self):
        path = filedialog.askopenfilename(title="Abrir dados", filetypes=[
            ("Dados de vibração", "*.ltd *.LTD *.csv *.txt *.dat *.wav *.npy *.npz"), ("Todos", "*.*")])
        if path:
            self.load_path(path)

    def load_path(self, path):
        fs_txt = self.v["fs"].get().strip()
        fs = float(fs_txt) if fs_txt else None
        try:
            ds = readers.read_any(path, fs=fs)
        except readers.LTDFormatError as exc:
            if messagebox.askyesno("LTD não reconhecido", f"{exc}\n\nAbrir o importador binário bruto?"):
                self.open_raw(path)
            return
        except Exception as exc:
            if Path(path).suffix.lower() in (".npy", ".npz", ".csv", ".txt", ".dat") and not fs:
                messagebox.showerror("Informe fs", f"{exc}\n\nPreencha 'fs [Hz]' e abra novamente.")
            else:
                messagebox.showerror("Erro ao abrir", str(exc))
            return
        self._set_dataset(ds)

    def open_raw(self, path=None):
        path = path if isinstance(path, str) else filedialog.askopenfilename(title="Arquivo binário")
        if not path:
            return
        try:
            info = readers.ltd_inspect(path)
        except Exception:
            info = {"guessed_data_offset": 0, "size": 0}
        dlg = tk.Toplevel(self)
        dlg.title("Importar binário bruto")
        dlg.transient(self)
        f = {k: tk.StringVar(value=v) for k, v in dict(
            dtype="<i2", n=str(1), offset=str(info["guessed_data_offset"]),
            fs=self.v["fs"].get() or "10000", scale="1.0").items()}
        inter = tk.BooleanVar(value=True)
        for i, (lab, key) in enumerate([("Tipo (<i2,<i4,<f4,<f8,<u2)", "dtype"), ("Nº de canais", "n"),
                                        ("Offset dos dados [bytes]", "offset"), ("fs [Hz]", "fs"),
                                        ("Fator de escala", "scale")]):
            ttk.Label(dlg, text=lab).grid(row=i, column=0, sticky="w", padx=6, pady=2)
            ttk.Entry(dlg, textvariable=f[key], width=14).grid(row=i, column=1, padx=6)
        ttk.Checkbutton(dlg, text="Canais intercalados", variable=inter).grid(row=5, column=0, columnspan=2)

        def go():
            try:
                ds = readers.read_raw(path, float(f["fs"].get()), f["dtype"].get(), int(f["n"].get()),
                                      int(f["offset"].get()), inter.get(), float(f["scale"].get()))
            except Exception as exc:
                messagebox.showerror("Erro", str(exc), parent=dlg)
                return
            dlg.destroy()
            self._set_dataset(ds)
        ttk.Button(dlg, text="Importar", command=go).grid(row=6, column=0, columnspan=2, pady=6)

    def estimate_rpm(self):
        if self.s.data is None:
            return
        try:
            f1, rpm, amp = self.s.estimate_rpm(self._selected()[0])
        except Exception as exc:
            messagebox.showerror("Rotação", str(exc))
            return
        self.v["rpm"].set(f"{rpm:.2f}")
        self.status.set(f"Rotação estimada: {f1:.3f} Hz = {rpm:.1f} rpm (amplitude {amp:.4g})")
        self.refresh()

    def load_brg(self):
        path = filedialog.askopenfilename(title="Tabela de rolamentos", filetypes=[("BRG", "*.brg *.BRG *.txt"), ("Todos", "*.*")])
        if not path:
            return
        try:
            self.table = bearings.load_brg(path)
        except Exception as exc:
            messagebox.showerror("Erro no .BRG", str(exc))
            return
        names = [b.name for b in self.table]
        self.cb_brg.configure(values=names)
        self.v["bearing"].set(names[0])
        self.refresh()

    # ------------------------------------------------------------------ plotting
    def _selected(self):
        return [self.lb.get(i) for i in self.lb.curselection()] or self.s.data.names[:1]

    def current_tab(self):
        return TABS[self.nb.index(self.nb.select())]

    def refresh(self):
        if self.s.data is None:
            return
        try:
            self._read_params()
            tab = self.current_tab()
            fig = self.figs[tab]
            chs = self._selected()
            info = ""
            if tab == "Tempo":
                self.s.fig_time(fig, chs)
            elif tab == "Espectro":
                self.s.fig_spectrum(fig, chs)
                info = "Picos: " + self.s.peaks_text()
            elif tab == "Coerência":
                self.s.fig_coherence(fig, self.v["ref_channel"].get(), chs[0])
            elif tab == "Envelope":
                self.s.fig_envelope(fig, chs[0])
                info = "Picos do envelope: " + self.s.peaks_text()
            elif tab == "Waterfall":
                self.s.fig_waterfall(fig, chs[0])
            elif tab == "Rainflow":
                info = self.s.fig_rainflow(fig, chs[0])
            bt = self.s.bearing_text()
            self.info.set((info + ("\nRolamento: " + bt if bt else "")).strip())
            self.canvases[tab].draw_idle()
        except Exception as exc:
            self.status.set(f"Erro: {exc}")

    # ------------------------------------------------------------------ cursors
    def on_click(self, ev, tab):
        if tab not in CURSOR_TABS or ev.inaxes is None or ev.button != 1 or self.s.data is None:
            return
        if self.canvases[tab].toolbar and getattr(self.canvases[tab].toolbar, "mode", ""):
            return
        spec = getattr(self.s, "_last_spec", None)
        if spec is None:
            return
        f, a = spec
        fp, ap = self.s.set_cursor(ev.xdata, f, a)
        self.status.set(f"Cursor: {fp:.3f} Hz  amplitude {ap:.4g}"
                        + (f"   período {1000 / fp:.3f} ms" if fp > 0 else ""))
        self.refresh()

    def on_motion(self, ev):
        if ev.inaxes is not None and ev.xdata is not None and self.current_tab() in CURSOR_TABS:
            self.status.set(f"f = {ev.xdata:.2f} Hz   y = {ev.ydata:.4g}")

    def clear_cursor(self):
        self.s.cursor_f0 = None
        self.refresh()

    # ------------------------------------------------------------------ export
    def save_fig(self):
        path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG", "*.png"), ("PDF", "*.pdf"), ("SVG", "*.svg")])
        if path:
            self.figs[self.current_tab()].savefig(path, dpi=150)

    def export_csv(self):
        spec = getattr(self.s, "_last_spec", None)
        if spec is None:
            messagebox.showinfo("Exportar", "Gere um espectro primeiro.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")])
        if path:
            with open(path, "w", newline="") as fh:
                w = csv.writer(fh, delimiter=";")
                w.writerow(["freq_Hz", "valor"])
                w.writerows(zip(*spec))


def main(argv=None):
    import sys
    argv = sys.argv[1:] if argv is None else argv
    app = App()
    if argv and Path(argv[0]).exists():           # "Abrir com FFTLab" / associacao de arquivo
        app.after(300, lambda: app.load_path(argv[0]))
    app.mainloop()


if __name__ == "__main__":
    main()
