"""Command line front-end: python -m fftlab.cli FILE --channel ch1 --out out_dir ..."""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
from matplotlib.figure import Figure

from . import bearings, readers
from .session import Session


def main(argv=None):
    ap = argparse.ArgumentParser(prog="fftlab-cli", description="Analises FFT/rolamentos/rainflow em lote")
    ap.add_argument("file")
    ap.add_argument("--fs", type=float, help="taxa de amostragem [Hz] (se o arquivo nao traz tempo)")
    ap.add_argument("--channel", "-c", action="append", help="canal (repetir p/ varios)")
    ap.add_argument("--ref", help="canal de referencia p/ coerencia")
    ap.add_argument("--rpm", type=float, default=0.0)
    ap.add_argument("--auto-rpm", metavar="CANAL", help="estima a rotacao 1x pelo pico dominante deste canal")
    ap.add_argument("--brg", help="arquivo .BRG")
    ap.add_argument("--bearing", help="nome do rolamento dentro do .BRG")
    ap.add_argument("--band", nargs=2, type=float, metavar=("LO", "HI"), help="banda do envelope [Hz]")
    ap.add_argument("--env-method", type=int, choices=(1, 2), default=1)
    ap.add_argument("--nperseg", type=int, default=16384)
    ap.add_argument("--fmax", type=float, default=0.0)
    ap.add_argument("--out", default="fftlab_out")
    ap.add_argument("--only", nargs="*", choices=("spectrum", "coherence", "envelope", "waterfall", "rainflow"))
    a = ap.parse_args(argv)

    s = Session().load(readers.read_any(a.file, fs=a.fs))
    s.params.rpm, s.params.fmax = a.rpm, a.fmax
    s.params.nperseg = min(a.nperseg, s.params.nperseg) if a.nperseg == 16384 else a.nperseg
    s.params.env_method = a.env_method
    if a.band:
        s.params.band_lo, s.params.band_hi = a.band
    if a.rpm == 0 and a.auto_rpm:
        f1, rpm, amp = s.estimate_rpm(a.auto_rpm)
        s.params.rpm = rpm
        print(f"Rotacao estimada em {a.auto_rpm}: {f1:.3f} Hz = {rpm:.1f} rpm (amp {amp:.3g})")
    if a.brg:
        tbl = bearings.load_brg(a.brg)
        s.bearing = next((b for b in tbl if b.name == a.bearing), tbl[0]) if a.bearing else tbl[0]
    chs = a.channel or s.data.names[:1]
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    todo = a.only or ["spectrum", "envelope", "waterfall", "rainflow"] + (["coherence"] if a.ref else [])
    print(f"{a.file}: fs={s.data.fs:g} Hz, {s.data.n_samples} amostras, {s.data.notes}")
    print("canais:", ", ".join(f"{n} [{s.data.units.get(n, '')}]" for n in s.data.names))
    if s.bearing and a.rpm:
        print("Rolamento", s.bearing.name, s.bearing_text())
    for step in todo:
        fig = Figure(figsize=(10, 6))
        if step == "spectrum":
            s.fig_spectrum(fig, chs)
            print("Picos:", s.peaks_text())
        elif step == "coherence":
            s.fig_coherence(fig, a.ref, chs[0])
        elif step == "envelope":
            s.fig_envelope(fig, chs[0])
            print("Picos envelope:", s.peaks_text())
        elif step == "waterfall":
            s.fig_waterfall(fig, chs[0])
        elif step == "rainflow":
            print(s.fig_rainflow(fig, chs[0]))
        fig.savefig(out / f"{step}.png", dpi=130)
    print("Graficos em", out.resolve())


if __name__ == "__main__":
    main()
