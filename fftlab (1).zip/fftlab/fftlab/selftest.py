"""Headless self-test used by the Windows build (CI) to prove the frozen exe works."""
import os
import sys
import tempfile
import traceback


def run() -> int:
    log = os.path.join(tempfile.gettempdir(), "fftlab_selftest.txt")
    try:
        import numpy as np
        import matplotlib
        matplotlib.use("Agg")
        from matplotlib.figure import Figure
        import tkinter  # noqa: F401  (GUI toolkit must be bundled)
        from . import dsp, rainflow, bearings, readers, plots
        from .session import Session

        fs = 2048.0
        t = np.arange(int(fs * 20)) / fs
        x = np.sin(2 * np.pi * 25 * t) + 0.1 * np.random.default_rng(0).normal(size=t.size)
        f, a, _ = dsp.auto_spectrum(x, fs, 4096)
        assert abs(f[a.argmax()] - 25) < 1, "spectrum"
        f1, rpm, _ = dsp.estimate_rotation(x, fs)
        assert abs(rpm - 1500) < 15, "rpm"
        c = rainflow.count_cycles(x[:4000])
        assert c.total > 10, "rainflow"
        b = bearings.Bearing("t", 9, 7.94, 39.04, 0)
        assert abs(b.bpfo_order - 3.585) < 0.01, "bearing"
        s = Session().load(readers.Dataset({"ch": x}, fs))
        s.fig_time(Figure(), ["ch"])
        s.fig_spectrum(Figure(), ["ch"])
        s.fig_envelope(Figure(), "ch")
        s.fig_waterfall(Figure(), "ch")
        s.fig_rainflow(Figure(), "ch")
        with open(log, "w") as fh:
            fh.write("OK\n")
        return 0
    except Exception:
        with open(log, "w") as fh:
            fh.write("FAIL\n" + traceback.format_exc())
        return 1


if __name__ == "__main__":
    sys.exit(run())
