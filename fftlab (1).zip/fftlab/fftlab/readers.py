"""File readers. Every reader returns a Dataset."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np


@dataclass
class Dataset:
    channels: dict            # name -> 1D float array
    fs: float                 # sampling rate [Hz]
    units: dict = field(default_factory=dict)
    source: str = ""
    notes: str = ""
    meta: dict = field(default_factory=dict)

    @property
    def names(self):
        return list(self.channels)

    @property
    def n_samples(self):
        return min(len(v) for v in self.channels.values())


class LTDFormatError(Exception):
    pass


# ---------------------------------------------------------------- CSV / TXT
def read_csv(path, fs=None, time_column=True, delimiter=None, skip_header="auto") -> Dataset:
    """Delimited text. If time_column, column 0 is time [s] and fs is derived from it."""
    text = Path(path).read_text(encoding="utf-8-sig", errors="replace")
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if not lines:
        raise ValueError("Arquivo vazio")
    if delimiter is None:
        delimiter = next((d for d in (";", "\t", ",") if d in lines[0]), None)  # None => whitespace

    def split(ln):
        return [p.strip() for p in (ln.split(delimiter) if delimiter else ln.split())]

    def isnum(s):
        try:
            float(s.replace(",", ".") if delimiter != "," else s)
            return True
        except ValueError:
            return False

    first = split(lines[0])
    has_header = (skip_header is True) or (skip_header == "auto" and not all(isnum(p) for p in first if p))
    names = first if has_header else [f"col{i}" for i in range(len(first))]
    body = lines[1:] if has_header else lines
    rows = []
    for ln in body:
        parts = split(ln)
        if len(parts) != len(names):
            continue
        try:
            rows.append([float(p.replace(",", ".") if delimiter != "," else p) for p in parts])
        except ValueError:
            continue
    if not rows:
        raise ValueError("Nenhuma linha numerica encontrada")
    arr = np.array(rows)
    if time_column:
        t = arr[:, 0]
        span = t[-1] - t[0]
        if len(t) < 2 or span <= 0 or np.median(np.diff(t)) <= 0:
            raise ValueError("Coluna de tempo nao e crescente")
        fs_eff = (len(t) - 1) / span   # robusto a arredondamento da coluna de tempo
        names, arr = names[1:], arr[:, 1:]
    else:
        if not fs:
            raise ValueError("Informe a taxa de amostragem (fs)")
        fs_eff = float(fs)
    return Dataset({n: arr[:, i].copy() for i, n in enumerate(names)}, fs_eff, source=str(path))


# ---------------------------------------------------------------- WAV / NPY
def read_wav(path) -> Dataset:
    from scipy.io import wavfile
    fs, data = wavfile.read(path)
    data = np.asarray(data)
    if np.issubdtype(data.dtype, np.integer):
        data = data.astype(float) / np.iinfo(data.dtype).max
    data = np.atleast_2d(data.T).astype(float)
    return Dataset({f"ch{i + 1}": data[i] for i in range(data.shape[0])}, float(fs), source=str(path))


def read_npy(path, fs) -> Dataset:
    arr = np.load(path)
    if hasattr(arr, "files"):  # npz
        ch = {k: np.asarray(arr[k], float).ravel() for k in arr.files}
    else:
        arr = np.atleast_2d(np.asarray(arr, float))
        if arr.shape[0] > arr.shape[1]:
            arr = arr.T
        ch = {f"ch{i + 1}": arr[i] for i in range(arr.shape[0])}
    return Dataset(ch, float(fs), source=str(path))


# ---------------------------------------------------------------- raw binary
def read_raw(path, fs, dtype="<i2", n_channels=1, offset=0, interleaved=True,
             scale=1.0, names=None) -> Dataset:
    """Generic headerless binary import (also usable for .LTD once the header size is known)."""
    dt = np.dtype(dtype)
    raw = np.fromfile(path, dtype=dt, offset=int(offset))
    n = (raw.size // n_channels) * n_channels
    raw = raw[:n].astype(float) * scale
    if interleaved:
        data = raw.reshape(-1, n_channels).T
    else:
        data = raw.reshape(n_channels, -1)
    names = names or [f"ch{i + 1}" for i in range(n_channels)]
    return Dataset({nm: data[i].copy() for i, nm in enumerate(names)}, float(fs), source=str(path),
                   notes=f"raw {dtype}, offset={offset}, interleaved={interleaved}")


# ---------------------------------------------------------------- Lynx LTD
# Layout (reverse-engineered from real files, "Lynx time domain"):
#   bytes 0..15   ASCII magic b"Lynx time domain"
#   ...           fixed preamble, then a sequence of ARRAY blocks, each:
#                   <id:1><type:1> 01 c9 04 00 01 <256 entries>
#                 type 0x28 = int16, 0x38 = float32, 0x88 = Pascal strings (len byte + text)
#                 id 0xcc names | 0xcd units | 0xce sensors | 0xd0 ADC units |
#                    0xd1 eng. max @ +10 V | 0xd2 eng. min @ -10 V | 0xca/0xcb/0xd3 int16 tables
#   then SCALAR fields: 0xfa float32 sample rate [Hz] | 0xfb int64 samples per channel |
#                       0xfc float64 start time (Delphi TDateTime) | 0xfd site string | 0xfe string
#   ...           zero padded header; DATA = int16 little-endian, scan-interleaved,
#                 n_channels x n_samples, ending exactly at EOF.
# Engineering value = raw/32768*10 [V] * (max-min)/20 + (max+min)/2
LTD_MAGIC = b"Lynx time domain"
_ARRAY_RE = re.compile(rb"[\xc0-\xff][\x28\x38\x88]\x01\xc9\x04\x00\x01")
_DEFAULT_NAME = re.compile(r"^Channel \d+$")


def _parse_ltd_header(blob: bytes) -> dict:
    import struct
    if not blob.startswith(LTD_MAGIC):
        raise LTDFormatError("Assinatura 'Lynx time domain' nao encontrada: nao e um .LTD desse tipo.")
    m = _ARRAY_RE.search(blob, 0, 4096)
    if not m:
        raise LTDFormatError("Tabelas de canais nao encontradas no cabecalho.")
    pos = m.start()
    pre = blob[16:pos]
    preamble = {}
    mo = re.search(rb"\x65\x50(.{8})", pre, re.S)          # int64: byte offset of the sample data
    if mo:
        preamble["data_offset"] = struct.unpack("<q", mo.group(1))[0]
    mc = re.search(rb"\xc8\x20(.{2})", pre[-8:], re.S)      # int16: number of recorded channels
    if mc:
        preamble["n_channels"] = struct.unpack("<h", mc.group(1))[0]
    arrays = {}
    while pos + 7 <= len(blob) and _ARRAY_RE.match(blob, pos):
        tid, typ = blob[pos], blob[pos + 1]
        pos += 7
        if typ == 0x28:
            arr = list(struct.unpack_from("<256h", blob, pos)); pos += 512
        elif typ == 0x38:
            arr = list(struct.unpack_from("<256f", blob, pos)); pos += 1024
        else:  # 0x88 Pascal strings
            arr = []
            for _ in range(256):
                n = blob[pos]
                arr.append(blob[pos + 1:pos + 1 + n].decode("latin-1")); pos += 1 + n
        arrays[tid] = arr
    scalars = {}
    while pos + 2 <= len(blob):
        tid, typ = blob[pos], blob[pos + 1]
        if tid == 0xfa and typ == 0x30:
            scalars["fs"] = struct.unpack_from("<f", blob, pos + 2)[0]; pos += 6
        elif tid == 0xfb and typ == 0x50:
            scalars["n_samples"] = struct.unpack_from("<q", blob, pos + 2)[0]; pos += 10
        elif tid == 0xfc and typ == 0x50:
            scalars["start"] = struct.unpack_from("<d", blob, pos + 2)[0]; pos += 10
        elif tid in (0xfd, 0xfe) and typ == 0x80:
            n = blob[pos + 2]
            scalars["site" if tid == 0xfd else "text"] = blob[pos + 3:pos + 3 + n].decode("latin-1"); pos += 3 + n
        else:
            break
    for need in ("fs", "n_samples"):
        if need not in scalars:
            raise LTDFormatError(f"Campo '{need}' nao encontrado no cabecalho do .LTD.")
    return {"arrays": arrays, "scalars": scalars, "header_end": pos, "preamble": preamble}


def ltd_inspect(path, max_bytes=65536) -> dict:
    """Diagnostic information about an .LTD file (works also for unknown binaries)."""
    p = Path(path)
    blob = p.read_bytes()[:max_bytes]
    runs = re.findall(rb"[\x20-\x7e\r\n\t]{6,}", blob[:12000])
    info = {"size": p.stat().st_size, "header_text": b"\n".join(runs).decode("latin-1"),
            "first_bytes_hex": blob[:64].hex(" "), "guessed_data_offset": 0}
    try:
        h = _parse_ltd_header(blob)
        info["parsed"] = {**h["scalars"], **h["preamble"]}
        info["guessed_data_offset"] = h["header_end"]
    except LTDFormatError:
        pass
    return info


def read_ltd(path, fs=None, raw=False, channels=None) -> Dataset:
    """Read a Lynx 'time domain' .LTD file.

    Returns channels converted to engineering units (set raw=True for ADC counts).
    `channels` optionally restricts the names/indices loaded (saves memory on big files).
    Text-style LTD files (header + numeric table) fall back to the CSV reader.
    """
    blob = Path(path).read_bytes()
    if not blob.startswith(LTD_MAGIC):
        sample = blob[:4096]
        printable = sum(32 <= b < 127 or b in (9, 10, 13) for b in sample) / max(1, len(sample))
        if printable > 0.97:
            ds = read_csv(path, fs=fs, time_column=fs is None)
            ds.notes = "LTD (texto) lido como tabela numerica"
            return ds
        raise LTDFormatError(
            "Arquivo .LTD nao reconhecido (assinatura 'Lynx time domain' ausente).\n"
            "Use 'Importar binario bruto'.\n" + ltd_inspect(path)["first_bytes_hex"])
    h = _parse_ltd_header(blob)
    arr, sc = h["arrays"], h["scalars"]
    names_all, units_all = arr.get(0xcc), arr.get(0xcd)
    if names_all is None:
        raise LTDFormatError("Tabela de nomes de canais (0xcc) ausente.")
    n_samples = int(sc["n_samples"])
    pre = h["preamble"]
    declared_nch = pre.get("n_channels")
    named_nch = max((i + 1 for i, n in enumerate(names_all) if n and not _DEFAULT_NAME.match(n)), default=0)
    nch = declared_nch if declared_nch and 0 < declared_nch <= 256 else named_nch
    if nch <= 0:
        raise LTDFormatError("Numero de canais nao encontrado no cabecalho.")
    data_off = pre.get("data_offset")
    if data_off is None:
        data_off = len(blob) - n_samples * nch * 2      # legacy fallback: data runs to EOF
    expected = data_off + n_samples * nch * 2
    if data_off < h["header_end"] or expected != len(blob):
        raise LTDFormatError(
            f"Tamanho incompativel: cabecalho declara {nch} canais x {n_samples} amostras a partir do byte "
            f"{data_off} (total {expected} bytes), mas o arquivo tem {len(blob)} bytes. "
            "Arquivo truncado/corrompido ou variante nao suportada.")
    mat = np.memmap(path, dtype="<i2", mode="r", offset=data_off, shape=(n_samples, nch))
    names = [names_all[i].strip() or f"ch{i + 1}" for i in range(nch)]
    units_adc = arr.get(0xd0, [""] * 256)
    vmax, vmin = arr.get(0xd1), arr.get(0xd2)
    want = list(range(nch))
    if channels is not None:
        want = [c if isinstance(c, int) else names.index(c) for c in channels]
    out, units = {}, {}
    for i in want:
        col = np.asarray(mat[:, i], dtype=np.float64)
        if raw or vmax is None or vmin is None:
            out[names[i]], units[names[i]] = col, "counts"
        else:
            volts = col * (10.0 / 32768.0)
            out[names[i]] = volts * ((vmax[i] - vmin[i]) / 20.0) + (vmax[i] + vmin[i]) / 2.0
            units[names[i]] = units_all[i] if units_all else ""
    del mat
    import datetime
    start = None
    if "start" in sc:
        start = (datetime.datetime(1899, 12, 30) + datetime.timedelta(days=sc["start"])).isoformat(timespec="milliseconds")
    meta = {"start": start, "site": sc.get("site", ""), "n_channels_file": nch,
            "sensors": {names[i]: (arr.get(0xce) or [""] * 256)[i] for i in want},
            "adc_units": {names[i]: units_adc[i] for i in want},
            "eng_range": {names[i]: (vmin[i], vmax[i]) for i in want} if vmax and vmin else {},
            "data_offset": data_off}
    note = f"{sc.get('site', '')} {start or ''}".strip()
    return Dataset(out, float(sc["fs"]) if not fs else float(fs), units, str(path), note, meta)


# ---------------------------------------------------------------- dispatch
def read_any(path, fs=None, **kw) -> Dataset:
    ext = Path(path).suffix.lower()
    if ext == ".ltd":
        return read_ltd(path, fs=fs if kw.pop("force_fs", False) else None, **kw)
    if ext == ".wav":
        return read_wav(path)
    if ext in (".npy", ".npz"):
        if not fs:
            raise ValueError("Informe fs para arquivos .npy/.npz")
        return read_npy(path, fs)
    if ext in (".csv", ".txt", ".dat", ".tsv"):
        return read_csv(path, fs=fs, time_column=fs is None, **kw)
    raise ValueError(f"Extensao nao suportada: {ext}")
