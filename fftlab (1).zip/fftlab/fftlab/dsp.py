"""Core signal-processing routines (no GUI dependencies)."""
from __future__ import annotations

import numpy as np
from scipy import signal

WINDOWS = {
    "hann": "hann",
    "hamming": "hamming",
    "blackman": "blackman",
    "flattop": "flattop",
    "bartlett": "bartlett",
    "retangular": "boxcar",
}


def get_window(name: str, n: int) -> np.ndarray:
    try:
        return signal.get_window(WINDOWS[name], n, fftbins=True)
    except KeyError as exc:
        raise ValueError(f"Janela desconhecida: {name!r}. Opcoes: {list(WINDOWS)}") from exc


def _check(x, fs):
    x = np.asarray(x, dtype=float)
    if x.ndim != 1 or x.size < 8:
        raise ValueError("Sinal precisa ser 1D com pelo menos 8 amostras.")
    if not fs > 0:
        raise ValueError("Taxa de amostragem deve ser > 0.")
    return x


# --------------------------------------------------------------------------
# Auto-spectrum
# --------------------------------------------------------------------------
def auto_spectrum(x, fs, nperseg=4096, overlap=0.5, window="hann",
                  scaling="peak", detrend="constant"):
    """Averaged (Welch) auto-spectrum.

    scaling:
      'peak' - amplitude spectrum: a sine of amplitude A shows a peak of A
      'rms'  - RMS amplitude spectrum
      'psd'  - power spectral density (units^2/Hz)
    Returns (f, spectrum, n_averages).
    """
    x = _check(x, fs)
    nperseg = int(min(nperseg, x.size))
    noverlap = int(round(nperseg * overlap))
    w = get_window(window, nperseg)
    kind = "density" if scaling == "psd" else "spectrum"
    f, p = signal.welch(x, fs=fs, window=w, nperseg=nperseg, noverlap=noverlap,
                        detrend=detrend, scaling=kind)
    step = nperseg - noverlap
    n_avg = 1 + (x.size - nperseg) // step
    if scaling == "psd":
        return f, p, n_avg
    rms = np.sqrt(p)
    if scaling == "rms":
        return f, rms, n_avg
    if scaling == "peak":
        return f, rms * np.sqrt(2.0), n_avg
    raise ValueError("scaling deve ser 'peak', 'rms' ou 'psd'")


def to_db(a, ref=1.0, floor=1e-20):
    return 20.0 * np.log10(np.maximum(np.abs(a), floor) / ref)


# --------------------------------------------------------------------------
# Coherence / cross-spectrum
# --------------------------------------------------------------------------
def coherence(x, y, fs, nperseg=4096, overlap=0.5, window="hann"):
    """Magnitude-squared coherence between x and y. Returns (f, Cxy)."""
    x = _check(x, fs)
    y = _check(y, fs)
    n = min(x.size, y.size)
    nperseg = int(min(nperseg, n))
    f, c = signal.coherence(x[:n], y[:n], fs=fs, window=get_window(window, nperseg),
                            nperseg=nperseg, noverlap=int(round(nperseg * overlap)))
    return f, c


def transfer_function(x, y, fs, nperseg=4096, overlap=0.5, window="hann"):
    """H1 estimator (input x -> output y). Returns (f, |H|, phase_deg)."""
    x = _check(x, fs)
    y = _check(y, fs)
    n = min(x.size, y.size)
    nperseg = int(min(nperseg, n))
    w = get_window(window, nperseg)
    no = int(round(nperseg * overlap))
    f, pxx = signal.welch(x[:n], fs, window=w, nperseg=nperseg, noverlap=no)
    _, pxy = signal.csd(x[:n], y[:n], fs, window=w, nperseg=nperseg, noverlap=no)
    h = pxy / np.maximum(pxx, 1e-30)
    return f, np.abs(h), np.degrees(np.angle(h))


# --------------------------------------------------------------------------
# Envelope analysis
# --------------------------------------------------------------------------
def bandpass(x, fs, f_lo, f_hi, order=4):
    nyq = fs / 2.0
    if not (0 < f_lo < f_hi < nyq):
        raise ValueError(f"Banda invalida: 0 < {f_lo} < {f_hi} < Nyquist ({nyq}) e necessario.")
    sos = signal.butter(order, [f_lo / nyq, f_hi / nyq], btype="bandpass", output="sos")
    return signal.sosfiltfilt(sos, x)


def envelope(x, fs, band, method=1, order=4):
    """Demodulated envelope of the band-passed signal.

    method 1: Hilbert envelope |analytic(x_band)|
    method 2: squared envelope |analytic(x_band)|^2 (emphasises repetitive impacts)
    """
    x = _check(x, fs)
    xb = bandpass(x - x.mean(), fs, band[0], band[1], order)
    env = np.abs(signal.hilbert(xb))
    if method == 2:
        env = env ** 2
    elif method != 1:
        raise ValueError("method deve ser 1 ou 2")
    return env


def envelope_spectrum(x, fs, band, method=1, fmax=None, window="hann", order=4):
    """Amplitude spectrum of the envelope (DC removed). Returns (f, amp, env)."""
    env = envelope(x, fs, band, method, order)
    e = env - env.mean()
    w = get_window(window, e.size)
    spec = np.abs(np.fft.rfft(e * w)) * 2.0 / w.sum()
    f = np.fft.rfftfreq(e.size, 1.0 / fs)
    if fmax:
        keep = f <= fmax
        f, spec = f[keep], spec[keep]
    return f, spec, env


# --------------------------------------------------------------------------
# Waterfall (STFT)
# --------------------------------------------------------------------------
def waterfall(x, fs, nperseg=2048, overlap=0.5, window="hann", scaling="peak"):
    """Short-time spectra. Returns (f, t, S) with S shaped (n_freq, n_frames)."""
    x = _check(x, fs)
    nperseg = int(min(nperseg, x.size))
    w = get_window(window, nperseg)
    f, t, z = signal.stft(x, fs=fs, window=w, nperseg=nperseg,
                          noverlap=int(round(nperseg * overlap)),
                          detrend="constant", boundary=None, padded=False)
    # scipy's STFT divides by sum(w); rescale to single-sided peak amplitude
    s = np.abs(z) * 2.0
    s[0, :] /= 2.0
    if scaling == "rms":
        s = s / np.sqrt(2.0)
    return f, t, s


# --------------------------------------------------------------------------
# Peaks / harmonics / cursors
# --------------------------------------------------------------------------
def find_peaks(f, a, n=10, min_prominence=None):
    """Return the n largest spectral peaks as list of (freq, amp)."""
    prom = min_prominence if min_prominence is not None else 0.05 * float(np.max(a))
    idx, _ = signal.find_peaks(a, prominence=prom)
    idx = idx[np.argsort(a[idx])[::-1]][:n]
    return [(float(f[i]), float(a[i])) for i in sorted(idx)]


def refine_peak(f, a, f0, tol_hz):
    """Snap f0 to the largest bin within +-tol_hz, with parabolic interpolation."""
    m = (f >= f0 - tol_hz) & (f <= f0 + tol_hz)
    if not m.any():
        return f0, 0.0
    i = int(np.argmax(np.where(m, a, -np.inf)))
    if 0 < i < len(a) - 1:
        y0, y1, y2 = a[i - 1], a[i], a[i + 1]
        d = y0 - 2 * y1 + y2
        if d != 0:
            delta = 0.5 * (y0 - y2) / d
            df = f[1] - f[0]
            return float(f[i] + delta * df), float(y1 - 0.25 * (y0 - y2) * delta)
    return float(f[i]), float(a[i])


def harmonic_freqs(f0, n_harm, fmax=None, sidebands=0, sideband_hz=0.0):
    """Harmonics k*f0 (k=1..n_harm), optionally with +-m*sideband_hz sidebands."""
    out = []
    for k in range(1, n_harm + 1):
        fk = k * f0
        if fmax and fk > fmax:
            break
        out.append((fk, f"{k}x"))
        for m in range(1, sidebands + 1):
            for sgn in (-1, 1):
                fs_ = fk + sgn * m * sideband_hz
                if fs_ > 0 and (not fmax or fs_ <= fmax):
                    out.append((fs_, f"{k}x{'+' if sgn > 0 else '-'}{m}sb"))
    return out


def estimate_rotation(x, fs, fmin=0.5, fmax=None):
    """Dominant low-frequency line (assumed 1x shaft speed). Returns (f_hz, rpm, amplitude)."""
    x = _check(x, fs)
    fmax = fmax or min(100.0, fs / 4)
    f, a, _ = auto_spectrum(x, fs, nperseg=min(x.size, int(fs * 60)), overlap=0.5, window="hann", scaling="peak")
    m = (f >= fmin) & (f <= fmax)
    i = int(np.argmax(np.where(m, a, -np.inf)))
    fp, ap = refine_peak(f, a, f[i], 2 * (f[1] - f[0]))
    return fp, fp * 60.0, ap
