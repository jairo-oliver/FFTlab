"""GUI-independent analysis session shared by the Tk GUI and the CLI."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from matplotlib.figure import Figure

from . import dsp, plots, rainflow as rf
from .bearings import Bearing
from .readers import Dataset


@dataclass
class Params:
    window: str = "hann"
    nperseg: int = 16384
    overlap: float = 0.5
    scaling: str = "peak"          # peak | rms | psd
    db: bool = False
    logx: bool = False
    fmin: float = 0.0
    fmax: float = 0.0              # 0 => Nyquist
    # envelope
    band_lo: float = 2000.0
    band_hi: float = 5000.0
    env_method: int = 1
    env_fmax: float = 500.0
    # waterfall
    wf_nperseg: int = 2048
    wf_mode: str = "lines"         # lines | top
    # machine
    rpm: float = 0.0
    n_harm: int = 5
    show_bearing: bool = True
    # rainflow
    rf_bins: int = 20
    sn_m: float = 3.0
    sn_ref_amp: float = 100.0
    sn_ref_cycles: float = 1e6


@dataclass
class Session:
    data: Optional[Dataset] = None
    params: Params = field(default_factory=Params)
    bearing: Optional[Bearing] = None
    cursor_f0: Optional[float] = None
    cursor_harmonics: bool = True
    last_peaks: list = field(default_factory=list)

    # ---- data
    def load(self, ds: Dataset):
        """Set the dataset and adapt band/frequency defaults to its sampling rate."""
        self.data = ds
        self.cursor_f0 = None
        nyq = ds.fs / 2.0
        p = self.params
        p.band_hi = round(min(5000.0, 0.8 * nyq), 1)
        p.band_lo = round(min(2000.0, 0.4 * p.band_hi), 1)
        p.env_fmax = round(min(500.0, 0.5 * nyq), 1)
        p.nperseg = int(min(p.nperseg, max(256, 2 ** int(np.log2(max(256, ds.n_samples))))))
        return self

    def unit(self, ch):
        return self._need().units.get(ch, "")

    def estimate_rpm(self, ch):
        d = self._need()
        return dsp.estimate_rotation(self._x(ch), d.fs)

    # ---- helpers
    def _need(self):
        if self.data is None:
            raise RuntimeError("Nenhum arquivo carregado")
        return self.data

    def _x(self, ch):
        d = self._need()
        if ch not in d.channels:
            raise KeyError(f"Canal {ch!r} nao existe. Disponiveis: {d.names}")
        return d.channels[ch]

    def _xlim(self):
        p = self.params
        d = self._need()
        hi = p.fmax or d.fs / 2
        return (p.fmin, hi)

    def machine_marks(self):
        """Marks for shaft harmonics and bearing defect frequencies."""
        p = self.params
        marks = []
        if p.rpm > 0:
            f1 = p.rpm / 60.0
            marks += [(f, l) for f, l in dsp.harmonic_freqs(f1, p.n_harm, self._need().fs / 2)]
            if self.bearing and p.show_bearing:
                for k, v in self.bearing.frequencies(f1).items():
                    if k != "2xBSF" and 0 < v < self._need().fs / 2:
                        marks.append((v, k))
        if self.cursor_f0:
            if self.cursor_harmonics:
                marks += [(f, f"C{l}") for f, l in dsp.harmonic_freqs(self.cursor_f0, p.n_harm, self._need().fs / 2)]
            else:
                marks.append((self.cursor_f0, "C"))
        return marks

    def set_cursor(self, f_click, f, a, tol_frac=0.01):
        """Snap the cursor to the nearest spectral peak around the clicked frequency."""
        tol = max(f_click * tol_frac, 2 * (f[1] - f[0]))
        fp, ap = dsp.refine_peak(f, a, f_click, tol)
        self.cursor_f0 = fp
        return fp, ap

    # ---- figures
    def fig_time(self, fig: Figure, channels):
        d = self._need()
        t = np.arange(d.n_samples) / d.fs
        return plots.plot_time(fig, t, {c: self._x(c) for c in channels}, self.unit(channels[0]))

    def fig_spectrum(self, fig, channels):
        p, d = self.params, self._need()
        spectra, peaks = {}, []
        for c in channels:
            f, a, n = dsp.auto_spectrum(self._x(c), d.fs, p.nperseg, p.overlap, p.window, p.scaling)
            spectra[f"{c} (n={n})"] = (f, a)
            peaks = dsp.find_peaks(f, a, 8)
        self.last_peaks = peaks
        self._last_spec = next(iter(spectra.values()))
        return plots.plot_spectrum(fig, spectra, p.scaling, p.db, p.logx, self._xlim(), self.machine_marks(),
                                   self.unit(channels[0]))

    def fig_coherence(self, fig, ch_a, ch_b):
        p, d = self.params, self._need()
        f, c = dsp.coherence(self._x(ch_a), self._x(ch_b), d.fs, p.nperseg, p.overlap, p.window)
        self._last_spec = (f, c)
        return plots.plot_coherence(fig, f, c, self._xlim(), self.machine_marks())

    def fig_envelope(self, fig, ch):
        p, d = self.params, self._need()
        x = self._x(ch)
        f, a, env = dsp.envelope_spectrum(x, d.fs, (p.band_lo, p.band_hi), p.env_method,
                                          fmax=p.env_fmax or None, window=p.window)
        self._last_spec = (f, a)
        self.last_peaks = dsp.find_peaks(f, a, 8)
        t = np.arange(len(x)) / d.fs
        return plots.plot_envelope(fig, f, a, t, x - x.mean(), env, (p.band_lo, p.band_hi),
                                   p.env_method, (0, p.env_fmax or d.fs / 2), self.machine_marks())

    def fig_waterfall(self, fig, ch):
        p, d = self.params, self._need()
        f, t, s = dsp.waterfall(self._x(ch), d.fs, p.wf_nperseg, p.overlap, p.window)
        return plots.plot_waterfall(fig, f, t, s, p.wf_mode, p.fmax or None, p.db)

    def fig_rainflow(self, fig, ch):
        p, d = self.params, self._need()
        x = self._x(ch)
        cyc = rf.count_cycles(x)
        t = np.arange(len(x)) / d.fs
        plots.plot_rainflow(fig, cyc, x, t, p.rf_bins, self.unit(ch))
        dmg = rf.miner_damage(cyc, p.sn_m, p.sn_ref_amp, p.sn_ref_cycles)
        deq = rf.damage_equivalent_range(cyc, p.sn_m)
        return (f"Ciclos totais: {cyc.total:.1f}   Faixa max: {cyc.ranges.max():.4g}   "
                f"Faixa equivalente (m={p.sn_m:g}): {deq:.4g}   Dano de Miner: {dmg:.3e}")

    def peaks_text(self):
        return "  |  ".join(f"{f:.2f} Hz: {a:.4g}" for f, a in self.last_peaks) or "-"

    def bearing_text(self):
        p = self.params
        if not (self.bearing and p.rpm > 0):
            return ""
        fr = self.bearing.frequencies(p.rpm / 60.0)
        return "  ".join(f"{k}={v:.2f} Hz" for k, v in fr.items())
