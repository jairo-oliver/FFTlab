@echo off
REM Build local no Windows (requer Python 3.10+ instalado SO NA MAQUINA DE BUILD; o usuario final nao precisa).
REM Execute a partir da pasta raiz do projeto:  packaging\build_windows.bat
setlocal
cd /d "%~dp0\.."
python -m venv .buildenv || goto :err
call .buildenv\Scripts\activate.bat || goto :err
python -m pip install --upgrade pip || goto :err
python -m pip install -r requirements.txt pyinstaller pytest || goto :err
python -m pytest tests -q || goto :err
pyinstaller packaging\fftlab.spec --noconfirm --distpath dist --workpath build || goto :err
echo Autoteste do executavel...
start /wait "" dist\FFTLab\FFTLab.exe --selftest
findstr /b "OK" "%TEMP%\fftlab_selftest.txt" >nul || (echo FALHA no autoteste do executavel & type "%TEMP%\fftlab_selftest.txt" & goto :err)
echo.
echo Executavel pronto: dist\FFTLab\FFTLab.exe
where iscc >nul 2>nul && (iscc /DMyAppVersion=0.3.0 packaging\installer.iss && echo Instalador: installer\FFTLab-Setup-0.3.0.exe) || echo (Para gerar o instalador, instale o Inno Setup 6 de jrsoftware.org e rode novamente.)
exit /b 0
:err
echo ERRO no build.
exit /b 1
