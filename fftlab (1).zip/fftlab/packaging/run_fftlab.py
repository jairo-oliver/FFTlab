"""Entry point used by PyInstaller (a plain script, so relative imports are not needed)."""
import sys

if "--selftest" in sys.argv:
    from fftlab.selftest import run
    sys.exit(run())

from fftlab.gui import main

main()
