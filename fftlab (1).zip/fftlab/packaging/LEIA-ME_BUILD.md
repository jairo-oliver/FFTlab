# Gerar o FFTLab como programa instalável do Windows (sem Python para o usuário final)

O resultado são dois arquivos:
* `FFTLab-Setup-<versão>.exe` - instalador (atalho no Menu Iniciar, desinstalador, opção de associar `.LTD`; instala sem precisar de administrador)
* `FFTLab-portatil.zip` - a mesma aplicação em pasta, sem instalar (rode `FFTLab\FFTLab.exe`)

O Python só é necessário **na hora de gerar** o executável. Quem for usar o programa não precisa de Python.

## Caminho A - automático, sem instalar nada (GitHub Actions) - recomendado
1. Crie uma conta gratuita em github.com e um repositório novo (pode ser **privado**).
2. Envie para ele todo o conteúdo desta pasta (incluindo a pasta oculta `.github`).
   Pelo site: *Add file → Upload files* e arraste tudo; confirme que `.github/workflows/build-windows.yml` ficou no repositório.
3. Aba **Actions → build-windows → Run workflow**. Leva alguns minutos.
4. Ao terminar, abra a execução e baixe o artefato **FFTLab-windows** (contém o instalador e o zip portátil).

O fluxo roda os testes, gera o .exe, executa um **autoteste do próprio .exe** (`FFTLab.exe --selftest`) e só então monta o instalador;
se algo falhar, ele para e mostra o erro.

## Caminho B - no seu PC com Windows
1. Instale o Python 3.10+ (python.org, marque *Add to PATH*) e, opcionalmente, o Inno Setup 6 (jrsoftware.org).
2. Na pasta do projeto: `packaging\build_windows.bat`
3. Saídas: `dist\FFTLab\FFTLab.exe` e, se o Inno Setup estiver instalado, `installer\FFTLab-Setup-<versão>.exe`.

## Observações
* O executável **não é assinado digitalmente**: o Windows SmartScreen pode mostrar "O Windows protegeu seu computador" (clique em *Mais informações → Executar assim mesmo*).
  Alguns antivírus também desconfiam de programas gerados com PyInstaller; gerar a versão em pasta (como aqui) reduz isso, e assinar o instalador com um certificado de código resolve.
* A aplicação em pasta é grande (numpy/scipy/matplotlib); espere algumas centenas de MB em disco e um instalador de dezenas de MB.
* Duplo clique em um `.LTD` abre direto no programa se você marcar "Associar arquivos .LTD" no instalador (ou use *Abrir com…*).
