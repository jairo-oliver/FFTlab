; Inno Setup script. Build:  iscc /DMyAppVersion=0.3.0 packaging\installer.iss   (run from project root)
#ifndef MyAppVersion
  #define MyAppVersion "0.3.0"
#endif

[Setup]
AppId={{5B0F2D8E-7C1A-4E52-9B63-FF7A1B0C7A11}
AppName=FFTLab
AppVersion={#MyAppVersion}
AppPublisher=FFTLab (software livre, MIT)
DefaultDirName={autopf}\FFTLab
DefaultGroupName=FFTLab
DisableProgramGroupPage=yes
OutputDir=..\installer
OutputBaseFilename=FFTLab-Setup-{#MyAppVersion}
Compression=lzma2/max
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
LicenseFile=..\LICENSE
UninstallDisplayIcon={app}\FFTLab.exe
WizardStyle=modern

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na Área de Trabalho"; Flags: unchecked
Name: "assocltd"; Description: "Associar arquivos .LTD ao FFTLab (Abrir com)"; Flags: unchecked

[Files]
Source: "..\dist\FFTLab\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\FFTLab"; Filename: "{app}\FFTLab.exe"
Name: "{group}\Desinstalar FFTLab"; Filename: "{uninstallexe}"
Name: "{autodesktop}\FFTLab"; Filename: "{app}\FFTLab.exe"; Tasks: desktopicon

[Registry]
Root: HKA; Subkey: "Software\Classes\.ltd\OpenWithProgids"; ValueType: string; ValueName: "FFTLab.ltd"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assocltd
Root: HKA; Subkey: "Software\Classes\FFTLab.ltd"; ValueType: string; ValueData: "Arquivo Lynx LTD"; Flags: uninsdeletekey; Tasks: assocltd
Root: HKA; Subkey: "Software\Classes\FFTLab.ltd\shell\open\command"; ValueType: string; ValueData: """{app}\FFTLab.exe"" ""%1"""; Tasks: assocltd

[Run]
Filename: "{app}\FFTLab.exe"; Description: "Abrir o FFTLab agora"; Flags: nowait postinstall skipifsilent
