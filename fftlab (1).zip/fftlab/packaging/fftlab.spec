# PyInstaller spec - run from the project root:  pyinstaller packaging/fftlab.spec --noconfirm
# Produces dist/FFTLab/FFTLab.exe (windowed, one-folder: starts faster and triggers fewer AV false positives than one-file).
import os
from PyInstaller.utils.hooks import collect_data_files

ROOT = os.path.abspath(os.path.join(SPECPATH, ".."))          # SPECPATH = pasta deste .spec

a = Analysis(
    [os.path.join(SPECPATH, "run_fftlab.py")],
    pathex=[ROOT],
    datas=collect_data_files("matplotlib") + [
        (os.path.join(ROOT, "examples", "rolamentos.brg"), "examples"),
        (os.path.join(ROOT, "README.md"), "."), (os.path.join(ROOT, "LICENSE"), ".")],
    hiddenimports=["matplotlib.backends.backend_tkagg", "matplotlib.backends.backend_agg"],
    excludes=["pytest", "IPython", "PyQt5", "PyQt6", "PySide2", "PySide6", "wx", "pandas", "numba", "notebook"],
)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name="FFTLab", console=False, icon=None)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="FFTLab")
