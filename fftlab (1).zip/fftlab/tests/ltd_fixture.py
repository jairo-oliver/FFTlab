"""Builds a synthetic Lynx-style .LTD file (same layout as real ones) for tests/examples."""
import struct
import numpy as np

PRE = b"\x01\xc9\x04\x00\x01"


def _arr_i16(tid, vals):
    v = list(vals) + [0] * (256 - len(vals))
    return bytes([tid, 0x28]) + PRE + struct.pack("<256h", *v)


def _arr_f32(tid, vals, default):
    v = list(vals) + [default] * (256 - len(vals))
    return bytes([tid, 0x38]) + PRE + struct.pack("<256f", *v)


def _arr_str(tid, vals, default=lambda i: ""):
    out = bytes([tid, 0x88]) + PRE
    for i in range(256):
        s = (vals[i] if i < len(vals) else default(i)).encode("latin-1")
        out += bytes([len(s)]) + s
    return out


def build_ltd(path, counts, names, units, vmax, vmin, fs, site="TESTE UG-01", start_days=46175.5,
              pad_to=28058):
    """counts: int16 array (n_samples, n_channels) of ADC counts."""
    n, nch = counts.shape
    pre = bytearray(b"Lynx time domain" + b"\x1a" + b"\x00" * 173)    # 190-byte preamble
    pre[145:155] = bytes([0x65, 0x50]) + struct.pack("<q", pad_to)       # data offset
    pre[186:190] = bytes([0xc8, 0x20]) + struct.pack("<h", nch)          # n channels
    blob = bytes(pre)
    blob += _arr_i16(0xca, [1] * 256) + _arr_i16(0xcb, list(range(256)))
    blob += _arr_str(0xcc, names, lambda i: f"Channel {i}")
    blob += _arr_str(0xcd, units, lambda i: "V")
    blob += _arr_str(0xce, ["sensor"] * nch)
    blob += _arr_f32(0xcf, [1.0] * nch, 0.0)
    blob += _arr_str(0xd0, ["V"] * 256)
    blob += _arr_f32(0xd1, vmax, 10.0) + _arr_f32(0xd2, vmin, -10.0) + _arr_i16(0xd3, [4] * 256)
    blob += bytes([0xfa, 0x30]) + struct.pack("<f", fs)
    blob += bytes([0xfb, 0x50]) + struct.pack("<q", n)
    blob += bytes([0xfc, 0x50]) + struct.pack("<d", start_days)
    s = site.encode()
    blob += bytes([0xfd, 0x80, len(s)]) + s + bytes([0xfe, 0x80, 0])
    assert len(blob) < pad_to
    blob += b"\x00" * (pad_to - len(blob))
    blob += np.ascontiguousarray(counts, dtype="<i2").tobytes()
    with open(path, "wb") as fh:
        fh.write(blob)
    return pad_to
