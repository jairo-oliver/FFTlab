import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import numpy as np
import matplotlib
matplotlib.use("Agg")
from matplotlib.figure import Figure
from fftlab import dsp, rainflow as rf, bearings, readers
from fftlab.session import Session

FS = 25600.0


def bearing_signal(seconds=10, shaft_hz=25.0, brg=None, seed=0):
    rng = np.random.default_rng(seed)
    n = int(FS * seconds)
    t = np.arange(n) / FS
    brg = brg or bearings.Bearing("6205", 9, 7.94, 39.04, 0.0)
    fdef = brg.bpfo_order * shaft_hz
    x = 1.0 * np.sin(2 * np.pi * shaft_hz * t) + 0.3 * np.sin(2 * np.pi * 2 * shaft_hz * t)
    # impact train with slight slip jitter, ringing a 4 kHz resonance
    k = np.arange(0, seconds * fdef)
    times = k / fdef + rng.normal(0, 0.0003, k.size)
    ring_t = np.arange(int(0.004 * FS)) / FS
    ring = np.exp(-ring_t * 1500) * np.sin(2 * np.pi * 4000 * ring_t)
    imp = np.zeros(n)
    for tk in times:
        i = int(tk * FS)
        if 0 <= i < n - ring.size:
            imp[i:i + ring.size] += ring
    return t, x + 0.8 * imp + 0.2 * rng.normal(size=n), fdef


def test_amplitude_scaling():
    t = np.arange(int(FS * 4)) / FS
    x = 2.5 * np.sin(2 * np.pi * 1000 * t)
    for w in ("hann", "flattop", "hamming"):
        f, a, _ = dsp.auto_spectrum(x, FS, 4096, 0.5, w, "peak")
        assert abs(a.max() - 2.5) < (0.05 if w != "hamming" else 0.2), (w, a.max())
        assert abs(f[a.argmax()] - 1000) < 7
    f, a, _ = dsp.auto_spectrum(x, FS, 4096, 0.5, "hann", "rms")
    assert abs(a.max() - 2.5 / np.sqrt(2)) < 0.05
    f, p, _ = dsp.auto_spectrum(x, FS, 4096, 0.5, "hann", "psd")
    assert abs(np.trapezoid(p, f) - 2.5 ** 2 / 2) < 0.05  # Parseval


def test_coherence():
    rng = np.random.default_rng(1)
    n = int(FS * 8)
    t = np.arange(n) / FS
    common = np.sin(2 * np.pi * 500 * t)
    a = common + 0.3 * rng.normal(size=n)
    b = 0.5 * common + 0.3 * rng.normal(size=n)
    f, c = dsp.coherence(a, b, FS, 2048)
    assert c[np.argmin(abs(f - 500))] > 0.95
    assert np.median(c[(f > 2000) & (f < 6000)]) < 0.2
    f, h, ph = dsp.transfer_function(a, b, FS, 2048)
    assert abs(h[np.argmin(abs(f - 500))] - 0.5) < 0.05


def test_envelope_finds_bpfo():
    t, x, fdef = bearing_signal()
    for m in (1, 2):
        f, a, _ = dsp.envelope_spectrum(x, FS, (3000, 5500), m, fmax=500)
        pk = f[np.argmax(np.where(f > 20, a, 0))]
        assert abs(pk - fdef) < 1.0, (m, pk, fdef)
    # the plain spectrum does NOT show the defect frequency clearly
    f, a, _ = dsp.auto_spectrum(x, FS, 16384)
    assert a[np.argmin(abs(f - fdef))] < 0.2


def test_bearing_formulas():
    b = bearings.Bearing("6205", 9, 7.94, 39.04, 0.0)
    assert abs(b.bpfo_order - 3.585) < 0.01
    assert abs(b.bpfi_order - 5.415) < 0.01
    assert abs(b.ftf_order - 0.398) < 0.01
    assert abs(b.bsf_order - 2.357) < 0.02
    assert abs((b.bpfo_order + b.bpfi_order) - b.n_balls) < 1e-9
    assert abs(b.frequencies(25.0)["BPFO"] - 89.6) < 0.5


def test_brg_roundtrip(tmp_path):
    p = tmp_path / "t.brg"
    bearings.save_brg(p, [bearings.Bearing("A", 9, 7.94, 39.04, 0), bearings.Bearing("B", 20, 24, 150, 10.5)])
    got = bearings.load_brg(p)
    assert [g.name for g in got] == ["A", "B"] and got[1].contact_deg == 10.5


def test_rainflow_astm():
    c = rf.count_cycles([-2, 1, -3, 5, -1, 3, -4, 4, -2])
    tab = {}
    for r, n in zip(c.ranges, c.counts):
        tab[r] = tab.get(r, 0) + n
    assert tab == {3.0: 0.5, 4.0: 1.5, 6.0: 0.5, 8.0: 1.0, 9.0: 0.5}


def test_rainflow_sine_and_damage():
    x = 50 * np.sin(2 * np.pi * np.arange(0, 100.2, 0.01) / 1.0)  # 100 cycles, amp 50
    c = rf.count_cycles(x)
    assert abs(c.total - 100) < 1.5
    big = c.ranges > 90
    assert abs(c.ranges[big].mean() - 100) < 0.5
    d = rf.miner_damage(c, 3.0, 50.0, 1e4)  # amp==ref -> N=1e4 -> D = 100/1e4
    assert abs(d - 100 / 1e4) < 2e-4
    assert abs(rf.damage_equivalent_range(c, 3.0, n_eq=c.total) - 100) < 1


def test_waterfall_tracks_sweep():
    t = np.arange(int(FS * 6)) / FS
    f_inst = 200 + 100 * t                        # 200 -> 800 Hz
    x = np.sin(2 * np.pi * np.cumsum(f_inst) / FS)
    f, tt, s = dsp.waterfall(x, FS, 4096, 0.5)
    pk = f[s.argmax(axis=0)]
    assert pk[0] < 300 and pk[-1] > 700 and np.all(np.diff(pk) >= -20)
    assert abs(s.max() - 1.0) < 0.15


def test_harmonics_and_refine():
    h = dsp.harmonic_freqs(25, 4, fmax=80, sidebands=1, sideband_hz=5)
    labels = [l for _, l in h]
    assert "3x" in labels and "4x" not in labels and "2x+1sb" in labels
    f = np.arange(0, 100, 0.5)
    a = np.exp(-0.5 * ((f - 33.2) / 0.7) ** 2)
    fp, ap = dsp.refine_peak(f, a, 33, 2)
    assert abs(fp - 33.2) < 0.15


def test_readers(tmp_path):
    t = np.arange(2000) / 1000.0
    p = tmp_path / "a.csv"
    p.write_text("t;acc;aux\n" + "\n".join(f"{ti:.4f};{np.sin(ti):.5f};{np.cos(ti):.5f}".replace(".", ",") for ti in t))
    d = readers.read_csv(p)
    assert d.names == ["acc", "aux"] and abs(d.fs - 1000) < 1
    raw = (np.arange(3000, dtype="<i2") % 100)
    q = tmp_path / "b.bin"
    q.write_bytes(b"HEADER__" + raw.tobytes())
    d = readers.read_raw(q, 5000, "<i2", 3, offset=8)
    assert d.n_samples == 1000 and len(d.names) == 3
    ltd = tmp_path / "x.ltd"
    ltd.write_bytes(b"\x00\x01LTDHDR" + bytes(range(256)) * 20)
    try:
        readers.read_ltd(ltd)
        assert False
    except readers.LTDFormatError:
        pass


def test_ltd_synthetic_roundtrip(tmp_path):
    from ltd_fixture import build_ltd
    n, fs = 8192, 1395.0
    t = np.arange(n) / fs
    volts = np.stack([3.0 + 0.5 * np.sin(2 * np.pi * 5.4545 * t),      # ch0 prox probe (um)
                      4.52 + 0 * t,                                       # ch1 power (MW)
                      2.0 * np.sin(2 * np.pi * 43.6 * t)], axis=1)       # ch2 vib (mm/s)
    counts = np.round(volts / 10 * 32768).astype("<i2")
    vmax, vmin = [4286.0, 65.27, 100.0], [-4755.0, -79.79, -100.0]
    p = tmp_path / "x.LTD"
    off = build_ltd(p, counts, ["PROX", "POT", "VIB"], ["um", "MW", "mm/s"], vmax, vmin, fs)
    d = readers.read_ltd(p)
    assert d.names == ["PROX", "POT", "VIB"] and abs(d.fs - fs) < 1e-3 and d.n_samples == n
    assert d.units["POT"] == "MW" and d.meta["data_offset"] == off and d.meta["n_channels_file"] == 3
    assert d.meta["start"].startswith("2026-06-02") and d.meta["site"] == "TESTE UG-01"
    # engineering conversion: V*(max-min)/20 + (max+min)/2
    exp_pot = 4.52 * (65.27 + 79.79) / 20 + (65.27 - 79.79) / 2
    assert abs(d.channels["POT"].mean() - exp_pot) < 0.01
    assert abs(d.channels["VIB"].std() - 2.0 / np.sqrt(2) * 10.0) < 0.1   # 10 mm/s per volt
    r = readers.read_ltd(p, raw=True, channels=["VIB"])
    assert list(r.channels) == ["VIB"] and r.units["VIB"] == "counts"
    assert abs(r.channels["VIB"].max() - 2.0 / 10 * 32768) < 2
    assert readers.read_any(p).n_samples == n
    # truncated file must fail loudly, not return garbage
    q = tmp_path / "trunc.LTD"
    q.write_bytes(p.read_bytes()[: off + 1000])
    try:
        readers.read_ltd(q)
        assert False
    except readers.LTDFormatError:
        pass


def test_rotation_estimate():
    t = np.arange(int(1395 * 120)) / 1395.0
    x = np.sin(2 * np.pi * 5.4545 * t) + 0.2 * np.sin(2 * np.pi * 10.909 * t) + 0.05 * np.random.default_rng(2).normal(size=t.size)
    f1, rpm, a = dsp.estimate_rotation(x, 1395.0)
    assert abs(f1 - 5.4545) < 0.02 and abs(rpm - 327.27) < 1.0 and abs(a - 1.0) < 0.05


def test_real_ltd_sample_if_present():
    import os
    path = os.environ.get("FFTLAB_LTD_SAMPLE")
    if not path or not os.path.exists(path):
        return
    d = readers.read_ltd(path)
    assert d.n_samples > 1000 and 10 < d.fs < 1e6 and len(d.names) >= 1


def test_session_figures_all():
    t, x, fdef = bearing_signal(6)
    from fftlab.readers import Dataset
    s = Session(data=Dataset({"acc": x, "ref": x * 0.7 + np.random.default_rng(3).normal(size=x.size) * 0.1}, FS))
    s.bearing = bearings.Bearing("6205", 9, 7.94, 39.04, 0.0)
    s.params.rpm = 1500
    s.params.band_lo, s.params.band_hi = 3000, 5500
    s.params.env_fmax = 400
    fig = Figure()
    s.fig_spectrum(fig, ["acc"])
    s.fig_coherence(fig, "ref", "acc")
    s.fig_envelope(fig, "acc")
    assert any(abs(f - fdef) < 1 for f, _ in s.last_peaks)
    s.fig_waterfall(fig, "acc")
    s.params.wf_mode = "top"
    s.fig_waterfall(fig, "acc")
    assert "Ciclos" in s.fig_rainflow(fig, "acc")
    s.fig_time(fig, ["acc", "ref"])
    s.fig_spectrum(fig, ["acc"])
    f, a = s._last_spec
    fp, ap = s.set_cursor(24.0, f, a)
    assert abs(fp - 25) < 1
    marks = s.machine_marks()
    assert any(l == "BPFO" for _, l in marks) and any(l.startswith("C") for _, l in marks)
    s.fig_spectrum(fig, ["acc"])
    assert "BPFO" in s.bearing_text()


if __name__ == "__main__":
    import pytest
    sys.exit(pytest.main([__file__, "-q"]))
